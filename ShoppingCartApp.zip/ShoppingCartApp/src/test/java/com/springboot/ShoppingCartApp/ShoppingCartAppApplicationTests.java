package com.springboot.ShoppingCartApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
