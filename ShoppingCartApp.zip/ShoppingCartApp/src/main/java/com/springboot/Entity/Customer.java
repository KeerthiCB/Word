package com.springboot.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="Customer")
public class Customer {

	@Id
	@Column(name="Customer_Id")
	private int customerId;
	
	@Column(name="Customer_Name")
	private String customerName;
	
	@Column(name="Zip_Code")
	private int zipCode;

	public Customer() {
		
	}
	

	public Customer(int customerId, String customerName, int zipCode) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.zipCode = zipCode;
	}


	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", zipCode=" + zipCode + "]";
	}
	
	
	
}
