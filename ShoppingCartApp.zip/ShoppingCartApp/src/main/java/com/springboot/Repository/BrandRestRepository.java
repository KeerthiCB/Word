package com.springboot.Repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.springboot.Entity.Brand;


@RepositoryRestResource(path = "brands", collectionResourceRel = "brandss")
public interface BrandRestRepository extends
PagingAndSortingRepository<Brand, Integer> {

	List<Brand> findByBrandName(@Param("brandName") String brandName);
	List<Brand> findByQuantity(@Param("quantity") int quantity);
}
