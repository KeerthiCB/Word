package com.springboot.Repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.springboot.Entity.Product;
@RepositoryRestResource(path = "products", collectionResourceRel = "products")
public interface ProductRestRepository extends
PagingAndSortingRepository<Product, Integer>{

	List<Product> findByProductName(@Param("productName") String productName);
	List<Product> findByBrand(@Param("brandName") String brandName);
}
